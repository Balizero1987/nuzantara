/**
 * ZANTARA Login Page - Email + PIN Authentication
 */

// Configuration - Use centralized API_CONFIG
const API_CONFIG = window.API_CONFIG || {
  backend: { url: 'https://nuzantara-rag.fly.dev' },
  memory: { url: 'https://nuzantara-rag.fly.dev' }
};
const API_BASE_URL = API_CONFIG.backend.url;

// DOM Elements
let emailInput, pinInput, pinToggle, loginButton, errorMessage, welcomeMessage, loginForm;

/**
 * Initialize login page
 */
document.addEventListener('DOMContentLoaded', async function() {
  console.log('🔐 ZANTARA Login Page Loading...');

  // Get DOM elements
  emailInput = document.getElementById('email');
  pinInput = document.getElementById('pin');
  pinToggle = document.getElementById('pinToggle');
  loginButton = document.getElementById('loginButton');
  errorMessage = document.getElementById('errorMessage');
  welcomeMessage = document.getElementById('welcomeMessage'); // Optional
  loginForm = document.getElementById('loginForm');
  
  // Verify critical elements exist
  if (!emailInput || !pinInput || !loginButton || !loginForm) {
    console.error('❌ Critical login elements missing!');
    return;
  }

  // Setup event listeners
  setupEventListeners();
  
  // Enable button if email is pre-filled (from URL params)
  if (emailInput && emailInput.value) {
    const urlParams = new URLSearchParams(window.location.search);
    const emailParam = urlParams.get('email');
    const pinParam = urlParams.get('pin');
    
    if (emailParam) {
      emailInput.value = emailParam;
    }
    if (pinParam && pinInput) {
      pinInput.value = pinParam;
      // Trigger validation
      handlePinInput({ target: pinInput });
    }
  }

  console.log('✅ Login page ready');
});

/**
 * Setup event listeners
 */
function setupEventListeners() {
  // Email input
  emailInput.addEventListener('blur', handleEmailBlur);
  emailInput.addEventListener('input', () => {
    clearError();
    // Re-validate button when email changes
    if (pinInput.value) {
      handlePinInput({ target: pinInput });
    }
  });

  // PIN input
  pinInput.addEventListener('input', handlePinInput);
  pinInput.addEventListener('input', clearError);

  // PIN toggle
  pinToggle.addEventListener('click', togglePinVisibility);

  // Form submit
  loginForm.addEventListener('submit', handleLogin);

  // Enter key navigation
  emailInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      pinInput.focus();
    }
  });
}

/**
 * Handle email blur
 */
function handleEmailBlur() {
  // Clear any messages on blur
  if (welcomeMessage) {
    welcomeMessage.classList.remove('show');
  }
}

/**
 * Handle PIN input - ensure numeric only
 */
function handlePinInput(e) {
  let value = e.target.value;

  // Remove non-numeric characters
  value = value.replace(/[^0-9]/g, '');

  // Update input
  if (value !== e.target.value) {
    e.target.value = value;
  }

  // Validate length
  const isValid = value.length >= 4 && value.length <= 8;

  // Enable/disable login button
  const emailValid = emailInput && emailInput.value.trim().length > 0;
  loginButton.disabled = !emailValid || !isValid;
  
  console.log('🔍 PIN validation:', { valueLength: value.length, isValid, emailValid, buttonDisabled: loginButton.disabled });
}

/**
 * Toggle PIN visibility
 */
function togglePinVisibility() {
  const isPassword = pinInput.type === 'password';
  pinInput.type = isPassword ? 'text' : 'password';
  pinToggle.textContent = isPassword ? '🙈' : '👁';
}

/**
 * Handle login form submission
 */
async function handleLogin(e) {
  e.preventDefault();

  const email = emailInput.value.trim();
  const pin = pinInput.value.trim();

  // Validate
  if (!email || !pin) {
    showError('Please enter both email and PIN');
    return;
  }

  if (!/^[0-9]{4,8}$/.test(pin)) {
    showError('PIN must be 4-8 digits');
    return;
  }

  // Show loading state
  loginButton.classList.add('loading');
  loginButton.disabled = true;
  clearError();

  try {
    console.log('🔐 Attempting login...');
    console.log('📍 API URL:', `${API_BASE_URL}/api/auth/demo`);
    console.log('📧 Email:', email);

    // Call auth API with email (backend accepts email or userId)
    // Backend doesn't validate password for demo endpoint
    const response = await fetch(`${API_BASE_URL}/api/auth/demo`, {
      method: 'POST',
      credentials: 'include', // Include cookies for CORS
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: email  // Backend accepts email or userId
      }),
    });
    
    console.log('📡 Response status:', response.status);
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ API Error:', errorText);
      throw new Error(`Login failed: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    console.log('✅ API Response:', result);

    // Login successful - handle actual backend response format
    // Backend returns: {token: "demo_xxx", expiresIn: 3600, userId: "demo"}
    const token = result.token || result.access_token;

    // CRITICAL: Verify token exists
    if (!token) {
      throw new Error('Server did not return authentication token. Please contact support.');
    }

    const expiresIn = result.expiresIn || result.expires_in || 3600; // 1 hour default
    const user = result.user || {
      id: result.userId || 'demo',
      email: email,
      name: email.split('@')[0]
    };

    console.log('✅ Login successful:', user.name || user.email);

    // Store auth data in ZANTARA format (zantara-*)
    localStorage.setItem('zantara-token', JSON.stringify({
      token: token,
      expiresAt: Date.now() + (expiresIn * 1000), // Convert seconds to milliseconds
    }));
    localStorage.setItem('zantara-user', JSON.stringify(user));
    localStorage.setItem('zantara-session', JSON.stringify({
      id: user.id || `session_${Date.now()}`,
      createdAt: Date.now(),
      lastActivity: Date.now(),
    }));

    console.log('✅ Auth data saved to localStorage (zantara-* format)');
    console.log('🔄 Redirecting to /chat.html...');

    // Show success message and redirect IMMEDIATELY
    if (welcomeMessage) {
      welcomeMessage.textContent = `Welcome back, ${user.name || user.email}! 🎉`;
      welcomeMessage.classList.add('show', 'success');
    }
    
    // CRITICAL: Redirect immediately (no delay)
    window.location.href = '/chat.html';

  } catch (error) {
    console.error('❌ Login failed:', error);

    // Show error message
    let errorMsg = error.message || 'Login failed';

    // User-friendly error messages
    if (errorMsg.includes('Invalid PIN')) {
      errorMsg = 'Invalid PIN. Please try again.';
    } else if (errorMsg.includes('User not found')) {
      errorMsg = 'Email not found. Please check your email.';
    } else if (errorMsg.includes('fetch')) {
      errorMsg = 'Connection error. Please check your internet.';
    }

    showError(errorMsg);

    // Reset loading state
    loginButton.classList.remove('loading');
    loginButton.disabled = false;

    // Clear PIN field on error
    pinInput.value = '';
    pinInput.focus();
  }
}

/**
 * Show error message
 */
function showError(message) {
  if (!errorMessage) return;
  
  // Use .error-text span if exists, otherwise use textContent
  const errorText = errorMessage.querySelector('.error-text');
  if (errorText) {
    errorText.textContent = message;
  } else {
    errorMessage.textContent = message;
  }
  
  errorMessage.style.display = 'block';
  errorMessage.classList.add('show');
}

/**
 * Clear error message
 */
function clearError() {
  if (errorMessage) {
    errorMessage.style.display = 'none';
    errorMessage.classList.remove('show');
  }
}

/**
 * Show success message
 */
function showSuccess(message) {
  // Optional: show success message if element exists
  if (welcomeMessage) {
    welcomeMessage.textContent = message;
    welcomeMessage.classList.add('show', 'success');
  } else {
    console.log('✅', message);
  }
  
  // Always redirect immediately (no delay needed if no UI feedback)
  window.location.href = '/chat.html';
}
