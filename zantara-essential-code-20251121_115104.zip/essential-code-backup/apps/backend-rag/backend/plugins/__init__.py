"""
ZANTARA Plugins Directory

This directory contains all plugin implementations organized by category.
"""
# ZANTARA Plugin System
