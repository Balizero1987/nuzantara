"""Team management plugins"""
