export class ForbiddenError extends Error {}
export class BadRequestError extends Error {}
export class UnauthorizedError extends Error {}
export class InternalServerError extends Error {}
export class BridgeError extends Error {}
