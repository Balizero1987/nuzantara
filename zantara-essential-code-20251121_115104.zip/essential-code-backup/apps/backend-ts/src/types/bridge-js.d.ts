declare module '../../bridge.ts' {
  const Bridge: any;
  export default Bridge;
}
