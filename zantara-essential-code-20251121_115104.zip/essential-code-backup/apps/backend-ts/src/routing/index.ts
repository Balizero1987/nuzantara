/**
 * Routing Module
 * Centralized routing configuration and exports
 */

export { attachRoutes } from './router.js';
