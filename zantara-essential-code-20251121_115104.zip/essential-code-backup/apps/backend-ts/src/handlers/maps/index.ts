/**
 * MAPS Module
 * Auto-generated module index
 */
export * from './maps.js';
