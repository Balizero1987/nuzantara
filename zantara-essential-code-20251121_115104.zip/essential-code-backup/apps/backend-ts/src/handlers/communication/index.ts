/**
 * COMMUNICATION Module
 * Auto-generated module index
 */
export * from './communication.js';
export * from './whatsapp.js';
export * from './instagram.js';
export * from './translate.js';
