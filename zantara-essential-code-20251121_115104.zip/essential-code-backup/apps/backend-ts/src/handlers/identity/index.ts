/**
 * IDENTITY Module
 * Auto-generated module index
 */
export * from './identity.js';
