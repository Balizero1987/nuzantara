/**
 * MEMORY Module
 * PRIORITY 5: Firestore handlers removed - using Python memory system
 * Only mock memory.ts remains for fallback
 */
export * from './memory.js';
