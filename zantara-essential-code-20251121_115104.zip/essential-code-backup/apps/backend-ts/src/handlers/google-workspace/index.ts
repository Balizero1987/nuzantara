/**
 * GOOGLE-WORKSPACE Module
 * Auto-generated module index
 */
export * from './gmail.js';
export * from './drive.js';
export * from './drive-multipart.js';
export * from './calendar.js';
export * from './docs.js';
export * from './sheets.js';
export * from './slides.js';
export * from './contacts.js';
