Reports directory for AI Code Quality Gate validation results
