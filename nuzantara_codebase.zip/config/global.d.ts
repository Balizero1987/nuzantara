// Type declarations for JS modules
declare module '*.js' {
  const value: any;
  export = value;
}
