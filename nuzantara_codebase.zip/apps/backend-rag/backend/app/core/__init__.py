"""
NUZANTARA PRIME - Core Module
Centralized configuration and core utilities
"""

from app.core.config import settings

__all__ = ["settings"]
