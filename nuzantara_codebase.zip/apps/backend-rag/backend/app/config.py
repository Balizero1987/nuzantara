"""
ZANTARA RAG - Configuration Management (DEPRECATED)
This file is kept for backward compatibility.
All new code should use app.core.config.settings
"""

# Import from centralized config
from app.core.config import settings

__all__ = ["settings"]
