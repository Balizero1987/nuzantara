"""
Tools Module
Tool loading, caching, and detection
"""

# ToolManager removed - using direct tool executor instead

__all__ = []
