"""
Intelligent Router - ZANTARA AI (REFACTORED)
Uses pattern matching for intent classification, routes to ZANTARA AI

Routing logic:
- PRIMARY AI → ZANTARA AI (configurable via environment variables)

PHASE 1 & 2 FIXES (2025-10-21):
- Response sanitization (removes training data artifacts)
- Length enforcement (SANTAI mode max 30 words)
- Conditional contact info (not for greetings)
- Query classification for RAG skip (NO RAG for greetings/casual)

REFACTORED (2025-11-05):
- Modular architecture with 6 specialized modules
- Orchestrator pattern - delegates to specialized services
- No code duplication between route_chat and stream_chat
- Independent, testable modules

REFACTORED (2025-12-01):
- Using ZANTARA AI exclusively (configurable via ZANTARA_AI_MODEL env var)
- AI engine abstraction allows switching models without code changes
"""

import logging
import time
import asyncio
from typing import Any, AsyncIterator

# Import modular components
from .classification import IntentClassifier
from .context import ContextBuilder, RAGManager
from .routing import ResponseHandler, SpecializedServiceRouter

# ToolManager removed - using tool_executor directly

logger = logging.getLogger(__name__)


class IntelligentRouter:
    """
    ZANTARA AI intelligent routing system (Orchestrator)

    Architecture:
    1. Pattern Matching: Fast intent classification (no AI cost)
    2. ZANTARA AI: Primary AI engine (configurable via environment)
    3. RAG Integration: Enhanced context for all business queries
    4. Tool Use: Full access to all 164 tools via ZANTARA AI

    AI Engine: Configurable via ZANTARA_AI_MODEL environment variable
    """

    def __init__(
        self,
        ai_client,
        search_service=None,
        tool_executor=None,
        cultural_rag_service=None,
        autonomous_research_service=None,
        cross_oracle_synthesis_service=None,
        client_journey_orchestrator=None,
        personality_service=None,
    ):
        """
        Initialize intelligent router with modular components

        Args:
            ai_client: ZantaraAIClient for ALL queries
            search_service: Optional SearchService for RAG
            tool_executor: ToolExecutor for handler execution (optional)
            cultural_rag_service: CulturalRAGService for Indonesian cultural context (optional)
            autonomous_research_service: AutonomousResearchService for complex queries (optional)
            cross_oracle_synthesis_service: CrossOracleSynthesisService for business planning (optional)
            client_journey_orchestrator: ClientJourneyOrchestrator for workflows (optional)
            personality_service: PersonalityService for Fast Track (optional)
        """
        # Core services
        self.ai = ai_client
        self.cultural_rag = cultural_rag_service
        self.personality_service = personality_service

        # Initialize modular components
        self.classifier = IntentClassifier()
        self.context_builder = ContextBuilder()
        self.rag_manager = RAGManager(search_service)
        self.specialized_router = SpecializedServiceRouter(
            autonomous_research_service, 
            cross_oracle_synthesis_service,
            client_journey_orchestrator
        )

        self.response_handler = ResponseHandler()
        # ToolManager removed - using tool_executor directly
        self.tool_executor = tool_executor

        logger.info("🎯 [IntelligentRouter] Initialized (ZANTARA AI, MODULAR)")
        logger.info(f"   Classification: {'✅' if True else '❌'} (Pattern Matching)")
        logger.info(f"   ZANTARA AI: {'✅' if ai_client else '❌'}")
        logger.info(f"   RAG: {'✅' if search_service else '❌'}")
        logger.info(f"   Tools: {'✅' if tool_executor else '❌'}")
        logger.info(f"   Cultural RAG: {'✅' if cultural_rag_service else '❌'}")
        logger.info(f"   Autonomous Research: {'✅' if autonomous_research_service else '❌'}")
        logger.info(f"   Cross-Oracle: {'✅' if cross_oracle_synthesis_service else '❌'}")
        logger.info(f"   Personality Service: {'✅' if personality_service else '❌'}")

    async def route_chat(
        self,
        message: str,
        user_id: str,
        conversation_history: list[dict] | None = None,
        memory: Any | None = None,
        emotional_profile: Any | None = None,
        last_ai_used: str | None = None,
        collaborator: Any | None = None,
        frontend_tools: list[dict] | None = None,
    ) -> dict:
        """
        Main routing function - classifies intent and routes to appropriate AI

        Args:
            message: User message
            user_id: User identifier
            conversation_history: Optional chat history
            memory: Optional memory context for user
            emotional_profile: Optional emotional profile from EmotionalAttunementService
            last_ai_used: Optional last AI used (for follow-up detection)
            collaborator: Optional collaborator profile for enhanced team personalization
            frontend_tools: Optional tools from frontend (if provided, use instead of backend tools)

        Returns:
            {
                "response": str,
                "ai_used": "zantara-ai",
                "category": str,
                "model": str,
                "tokens": dict,
                "used_rag": bool,
                "tools_called": List[str]
            }
        """
        try:
            logger.info(f"🚦 [Router] Routing message for user {user_id}")

            # STEP 0: Fast Intent Classification (Before RAG)
            intent = await self.classifier.classify_intent(message)
            category = intent["category"]
            suggested_ai = intent["suggested_ai"]
            logger.info(f"📋 [Router] Initial Classification: {category} (Confidence: {intent.get('confidence', 0.0)})")

            # STEP 0.5: Fast Track (Skip RAG/Gemini for greetings/casual)
            if category in ["greeting", "casual"] and self.personality_service:
                logger.info("🚀 [Router] FAST TRACK ACTIVATED: Skipping RAG & Gemini")
                fast_response = await self.personality_service.fast_chat(user_id, message) # user_id is email in this context usually
                return fast_response

            # STEP 1: Determine tools to use (frontend or backend)
            tools_to_use = frontend_tools
            if not tools_to_use and self.tool_executor:
                # Get tools directly from tool_executor if available
                tools_to_use = getattr(self.tool_executor, "get_available_tools", lambda: [])()
                if tools_to_use:
                    logger.info(f"🔧 [Router] Using {len(tools_to_use)} tools from BACKEND")
            else:
                logger.info(f"🔧 [Router] Using {len(tools_to_use)} tools from FRONTEND")

            # STEP 2: Classify query type for RAG and sanitization
            query_type = self.response_handler.classify_query(message)
            logger.info(f"📋 [Router] Query type: {query_type}")

            # STEP 3: RAG retrieval (only for business/emergency)
            rag_result = await self.rag_manager.retrieve_context(
                query=message, query_type=query_type, user_level=0, limit=5
            )

            # STEP 4: Check for emotional override
            if emotional_profile and hasattr(emotional_profile, "detected_state"):
                emotional_result = await self._handle_emotional_override(
                    message, user_id, conversation_history, memory, emotional_profile, tools_to_use
                )
                if emotional_result:
                    return emotional_result

            # STEP 5: Build memory context
            memory_context = self.context_builder.build_memory_context(memory)

            # STEP 6: Build team context
            team_context = self.context_builder.build_team_context(collaborator)

            # STEP 7: Get cultural context (if available)
            cultural_context = await self._get_cultural_context(message, conversation_history)

            # STEP 8: Combine all contexts
            combined_context = self.context_builder.combine_contexts(
                memory_context, team_context, rag_result["context"], cultural_context
            )

            # STEP 9: Re-classify intent (optional, but we already did it)
            # intent = await self.classifier.classify_intent(message)
            # category = intent["category"]
            # suggested_ai = intent["suggested_ai"]

            logger.info(f"   Category: {category} → AI: {suggested_ai}")

            # STEP 10: Check for specialized service routing
            # Autonomous Research
            if self.specialized_router.detect_autonomous_research(message, category):
                result = await self.specialized_router.route_autonomous_research(
                    message, user_level=3
                )
                if result:
                    return result

            # Cross-Oracle Synthesis
            if self.specialized_router.detect_cross_oracle(message, category):
                result = await self.specialized_router.route_cross_oracle(message, user_level=3)
                if result:
                    return result

            # Client Journey Orchestrator
            if self.specialized_router.detect_client_journey(message, category):
                result = await self.specialized_router.route_client_journey(message, user_id)
                if result:
                    return result

            # STEP 11: Route to ZANTARA AI
            logger.info("🎯 [Router] Using ZANTARA AI")

            if self.tool_executor and tools_to_use:
                logger.info(f"   Tool use: ENABLED ({len(tools_to_use)} tools)")
                result = await self.ai.conversational_with_tools(
                    message=message,
                    user_id=user_id,
                    conversation_history=conversation_history,
                    memory_context=combined_context,
                    tools=tools_to_use,
                    tool_executor=self.tool_executor,
                    max_tokens=8000,
                    max_tool_iterations=5,
                )
            else:
                logger.info("   Tool use: DISABLED")
                result = await self.ai.conversational(
                    message=message,
                    user_id=user_id,
                    conversation_history=conversation_history,
                    memory_context=combined_context,
                    max_tokens=8000,
                )

            # STEP 12: Sanitize response
            sanitized_response = self.response_handler.sanitize_response(
                result["text"], query_type, apply_santai=True, add_contact=True
            )

            return {
                "response": sanitized_response,
                "ai_used": result.get("ai_used", "zantara-ai"),  # Use actual AI used
                "category": category,
                "model": result["model"],
                "tokens": result["tokens"],
                "used_rag": rag_result["used_rag"],
                "used_tools": result.get("used_tools", False),
                "tools_called": result.get("tools_called", []),
            }

        except Exception as e:
            logger.error(f"❌ [Router] Routing error: {e}")
            raise Exception(f"Routing failed: {str(e)}")

    async def stream_chat(
        self,
        message: str,
        user_id: str,
        conversation_history: list[dict] | None = None,
        memory: Any | None = None,
        collaborator: Any | None = None,
    ):
        """
        Stream chat response token by token for SSE

        Args:
            message: User message
            user_id: User identifier
            conversation_history: Optional chat history
            memory: Optional memory context
            collaborator: Optional collaborator profile

        Yields:
            str: Text chunks as they arrive from AI
        """
        try:
            logger.info(f"🚦 [Router Stream] Starting stream for user {user_id}")

            # STEP 1: Classify query type
            query_type = self.response_handler.classify_query(message)
            logger.info(f"📋 [Router Stream] Query type: {query_type}")

            # STEP 2: Detect comparison/cross-topic queries (adjust max_tokens)
            comparison_keywords = [
                "confronta",
                "compare",
                "vs",
                "differenza tra",
                "difference between",
                "confronto",
                "comparison",
            ]
            cross_topic_keywords = [
                "timeline",
                "percorso completo",
                "tutti i costi",
                "step-by-step",
                "tutto",
                "complessivamente",
            ]

            is_comparison = any(kw in message.lower() for kw in comparison_keywords)
            is_cross_topic = (
                any(kw in message.lower() for kw in cross_topic_keywords)
                or len(message.split()) > 20
            )

            if is_comparison:
                max_tokens_to_use = 12000
                logger.info(f"🔍 COMPARISON query detected → max_tokens={max_tokens_to_use}")
            elif is_cross_topic:
                max_tokens_to_use = 10000
                logger.info(f"🌐 CROSS-TOPIC query detected → max_tokens={max_tokens_to_use}")
            else:
                max_tokens_to_use = 8000

            # STEP 2.5: Check for specialized service routing
            category = query_type

            # Autonomous Research
            if self.specialized_router.detect_autonomous_research(message, category):
                result = await self.specialized_router.route_autonomous_research(
                    message, user_level=3
                )
                if result:
                    # Yield result text as chunks
                    text = result.get("response", result.get("text", ""))
                    for word in text.split():
                        yield word + " "
                        await asyncio.sleep(0.02)
                    return

            # Cross-Oracle Synthesis
            if self.specialized_router.detect_cross_oracle(message, category):
                result = await self.specialized_router.route_cross_oracle(message, user_level=3)
                if result:
                    text = result.get("response", result.get("text", ""))
                    for word in text.split():
                        yield word + " "
                        await asyncio.sleep(0.02)
                    return

            # Client Journey Orchestrator
            if self.specialized_router.detect_client_journey(message, category):
                result = await self.specialized_router.route_client_journey(message, user_id)
                if result:
                    text = result.get("response", result.get("text", ""))
                    for word in text.split():
                        yield word + " "
                        await asyncio.sleep(0.02)
                    return

            # STEP 3: Build memory context
            memory_context = self.context_builder.build_memory_context(memory)

            # STEP 4: Build team context
            team_context = self.context_builder.build_team_context(collaborator)

            # STEP 5: RAG retrieval (only for business/emergency)
            rag_result = await self.rag_manager.retrieve_context(
                query=message, query_type=query_type, user_level=0, limit=5
            )

            # STEP 6: Combine contexts
            combined_context = self.context_builder.combine_contexts(
                memory_context, team_context, rag_result["context"], None
            )

            # STEP 7: Tools are used directly during AI call

            # STEP 9: Stream from ZANTARA AI
            logger.info("🎯 [Router Stream] Using ZANTARA AI with REAL token-by-token streaming")

            # Yield metadata first (custom format for frontend)
            # Format: [METADATA]json_string[METADATA]
            metadata = {
                "memory_used": True if memory and (memory.get("facts") or memory.get("summary")) else False,
                "rag_sources": [doc.metadata.get("source", "Unknown") for doc in rag_result.get("docs", [])] if rag_result else [],
                "team_member": collaborator.get("name") if collaborator else "Zantara",
                "intent": category
            }
            import json
            yield f"[METADATA]{json.dumps(metadata)}[METADATA]"

            async for chunk in self.ai.stream(
                message=message,
                user_id=user_id,
                conversation_history=conversation_history,
                memory_context=combined_context,
                max_tokens=max_tokens_to_use,
            ):
                yield chunk

            logger.info(f"✅ [Router Stream] Stream completed for user {user_id}")

        except Exception as e:
            logger.error(f"❌ [Router Stream] Error: {e}")
            raise Exception(f"Streaming failed: {str(e)}")

    async def _handle_emotional_override(
        self,
        message: str,
        user_id: str,
        conversation_history: list[dict] | None,
        memory: Any | None,
        emotional_profile: Any,
        tools_to_use: list[dict] | None,
    ) -> dict | None:
        """Handle emotional override routing (internal helper)"""
        emotional_states_needing_empathy = [
            "sad",
            "anxious",
            "stressed",
            "embarrassed",
            "lonely",
            "scared",
            "worried",
        ]

        detected_state = (
            emotional_profile.detected_state.value
            if hasattr(emotional_profile.detected_state, "value")
            else str(emotional_profile.detected_state)
        )

        if detected_state not in emotional_states_needing_empathy:
            return None

        logger.info(
            f"🎭 [Router] EMOTIONAL OVERRIDE: {detected_state} → Using ZANTARA AI for empathy"
        )

        memory_context = self.context_builder.build_memory_context(memory)

        if self.tool_executor and tools_to_use:
            result = await self.ai.conversational_with_tools(
                message=message,
                user_id=user_id,
                conversation_history=conversation_history,
                memory_context=memory_context,
                tools=tools_to_use,
                tool_executor=self.tool_executor,
                max_tokens=8000,
                max_tool_iterations=5,
            )
        else:
            result = await self.ai.conversational(
                message=message,
                user_id=user_id,
                conversation_history=conversation_history,
                memory_context=memory_context,
                max_tokens=8000,
            )

        return {
            "response": result["text"],
            "ai_used": "zantara-ai",
            "category": "emotional_support",
            "model": result["model"],
            "tokens": result["tokens"],
            "used_rag": False,
            "used_tools": result.get("used_tools", False),
            "tools_called": result.get("tools_called", []),
        }

    async def _get_cultural_context(
        self, message: str, conversation_history: list[dict] | None
    ) -> str | None:
        """Get cultural context from CulturalRAGService (internal helper)"""
        if not self.cultural_rag:
            return None

        try:
            context_params = {
                "query": message,
                "intent": "general",
                "conversation_stage": (
                    "first_contact"
                    if not conversation_history or len(conversation_history) < 3
                    else "ongoing"
                ),
            }

            cultural_chunks = await self.cultural_rag.get_cultural_context(context_params, limit=2)

            if cultural_chunks:
                logger.info(
                    f"🌴 [Cultural RAG] Injecting {len(cultural_chunks)} Indonesian cultural insights"
                )
                return self.cultural_rag.build_cultural_prompt_injection(cultural_chunks)

        except Exception as e:
            logger.warning(f"⚠️ [Cultural RAG] Failed: {e}")

        return None

    # _prefetch_tool_data method removed - tools are used directly during AI call

    def get_stats(self) -> dict:
        """Get router statistics"""
        return {
            "router": "zantara_ai_router",
            "classification": "pattern_matching",
            "ai_models": {
                "zantara_ai": {
                    "available": self.ai.is_available() if self.ai else False,
                    "use_case": "ALL queries (greetings, casual, business, complex)",
                    "cost": "$0.20/$0.20 per 1M tokens",
                    "traffic": "100%",
                    "engine": "ZANTARA AI (configurable via environment)",
                }
            },
            "rag_available": self.rag_manager.search is not None,
            "total_cost_monthly": "$8-15 (3,000 requests) - 3x cheaper than Sonnet",
        }
