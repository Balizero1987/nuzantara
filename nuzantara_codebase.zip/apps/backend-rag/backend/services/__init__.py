"""ZANTARA RAG - Services"""

from .search_service import SearchService

__all__ = ["SearchService"]
