"""Bali Zero service plugins"""
