"""ZANTARA RAG - Utilities"""
